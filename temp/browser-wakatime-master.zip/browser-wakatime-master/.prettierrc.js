module.exports = {
  plugins: [require('prettier-plugin-sort-json'), require('prettier-plugin-packagejson')],
  printWidth: 100,
  singleQuote: true,
  trailingComma: 'all',
};
