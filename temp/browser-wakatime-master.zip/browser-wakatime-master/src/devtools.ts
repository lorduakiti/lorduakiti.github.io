// eslint-disable-next-line @typescript-eslint/no-floating-promises
browser.devtools.panels.create('Wakatime', 'test.png', 'WakatimeDevPanel.html');
